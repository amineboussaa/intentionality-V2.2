const JwtStrategy = require('passport-jwt').Strategy;
const ExtractJwt = require('passport-jwt').ExtractJwt;
const User = require('../models/user');



module.exports = function (passport) {
    let user = new User();
    let opts = {};
    opts.jwtFromRequest = ExtractJwt.fromAuthHeaderWithScheme('jwt');
    opts.secretOrKey = "app-super-secret";
    passport.use(new JwtStrategy(opts,(jwt_playload,done)=>{
      try{
            user.getById(jwt_playload.user)
                  return (user?done(null,user):done(null,false));
                }catch(error){
                    return done(error,false);
                }
        }));
};
