const mysqlModel = require('mysql-model');
const connectionModel = mysqlModel.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : '',
    database : 'intentionaliydb'
});

module.exports = connectionModel;
