const nodemailer = require("nodemailer");

// create reusable transporter object using SMTP transport
const transporter = nodemailer.createTransport({
    service: 'Gmail',
    auth: {
        user: 'ahmededaly1993@gmail.com',
        pass: 'allahma3ak'
    }
});


module.exports = transporter;