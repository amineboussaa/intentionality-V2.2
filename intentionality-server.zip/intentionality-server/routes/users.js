const express = require('express');
const router = express.Router();
const passport = require('passport');
const bcrypt = require('bcrypt');
const saltRounds = 10;
const emailChk = require('email-chk');
const jwt = require('jsonwebtoken');
const User = require('../Models/User');
require('../config/passport')(passport);

let user = new User();

// GET users listing
router.get('/',passport.authorize('jwt',{ session : false}),function (request, response) {
  user.getAllUsers().then(function(data){
    console.log("Users fetched Successfully");
    response.json(data);
    response.end();
  }).catch(function(err){
    console.log("Failed to query form users: " + error);
    return response.sendStatus(500);
  });
});


// GET user by id

router.get('/:id',passport.authorize('jwt',{ session : false}), function (request, response) {

  let id = request.params.id;
  user.getById(id).then(function(data){
    console.log("User fetched Successfully");
    response.json(data);
  }).catch(function(err){
    console.log("Failed to query form users: " + error);
    return response.sendStatus(500);
  });

});

// Add new User

router.post('/singup',async function (request, response) {
  try{
    let body = request.body;
    let checkuser = await user.getByEmail(body.email);
    if(checkuser.length == 0){
      let emailcheck = await emailChk(body.email);
      if(emailcheck === true){
        request.body.password = await bcrypt.hash(body.password, saltRounds);
        let newUser = new User(body);
        await newUser.addUser();
        response.json({
          "status": "ok",
          "code": 200,
          "messages": [],
        });
      }else{
        response.sendStatus(422);
      }
    }else{
      response.sendStatus(422);
    }
  }catch(err){
    console.log("Failed to insert new user: " + err);
    return response.sendStatus(500);}
  });

  // Update a User

  router.put('/update/:id',passport.authorize('jwt',{ session : false}), function (request, response) {
    let id = request.params.id;
    let body = request.body;
    let newUser = new User(body);
    newUser.set('id',id);
    newUser.addUser().then(function(data){
      console.log("user updated");
      response.sendStatus(200);
    }).catch(function(err){
      console.log("Failed to insert new user: " + err);
      return response.sendStatus(500);
    });
  });


  //Login
  router.post('/login', async function (request, response) {
    const email = request.body.email;
    const password = request.body.password;
    try{
      let data = await user.getByEmail(email);
      if(data.length == 0){
        response.sendStatus(401);
      }else{
        if( await bcrypt.compare(password,data.password)){
          const token = jwt.sign({user : data.id }, 'app-super-secret' , {
            expiresIn: 604800 // une semaine
          });
          response.json({
            status: 200,
            success : true ,
            id: data.id,
            role: data.role,
            token: 'JWT '+ token
          });
        }else{
          response.sendStatus(401);
        }
      }
    }catch(err){
      console.log(err);
      response.json({success: false, msg: err.msg});
    }
  });

// activated / deactivated a User 
router.get('/de_activate/:id',passport.authorize('jwt',{ session : false}),async function (request, response, next) {
  try{
    let result = await user.getById(request.params.id);
    let newUser = new User(result);
    console.log(newUser);
    let isActif = (result.isActif === 0)? 1 : 0;
    newUser.set('isActif',isActif);
    result = await newUser.addUser();
    console.log("user activated / deactivated successfully");
    return response.json({
      "status": "ok",
      "code": 200,
      "messages": [],
    });
  }catch(err){
    console.log("Failed to activated / deactivated user: "+err);
    return response.sendStatus(500);
  }
});


  module.exports = router;
