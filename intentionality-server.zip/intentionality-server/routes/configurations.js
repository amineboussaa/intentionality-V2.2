let express = require('express');
let router = express.Router();
let configModel = require('../Models/Configuration');
const passport = require('passport');
require('../config/passport')(passport);

let config = new configModel();

//GET The Configuration 

router.get('/',passport.authorize('jwt',{ session : false}), async function (request, response) {
    try{
        let data = await config.getConfiguration();
        response.json(data);
    }catch(err){
        response.sendStatus(500);
    }
});


//Update  Configuration 

router.put('/update',passport.authorize('jwt',{ session : false}), async function (request,response) {
    try{
        let newConfig = new configModel(request.body);
        newConfig.set('id',1);
        let data = await newConfig.updateConfiguration();
        console.log("configuration was updated Successfully ");
        return  response.sendStatus(200);
    }catch(err){
        console.log("failed to update configuration "+error);
        return response.sendStatus(500);
    }
});

module.exports = router;
