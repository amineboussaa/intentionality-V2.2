const express = require('express');
const router = express.Router();
const Organisation = require('../Models/Organisation');
const Project = require('../Models/Project');

let org = new Organisation();
let project = new Project();


router.get('/list', async function(request,response){
    try{
        let result = await org.getAllOrganisations();
        let organisations =  await Promise.all( result.map(async (element) => {
            let projects = await project.getProjectsByOrganisation(element.id);
            element.projects = projects;
            return element;
        }));
        response.json({
            statut: 200,
            data: organisations
        });
    }catch(err){
        console.log(err);
        response.sendStatus(500);
    }
});

router.get('/details/:orgId', async function(request,response){
    try{
        let result = await org.getOrganisation(request.params.orgId);
        response.json({
            statut: 200,
            data: result
        });
    }catch(err){
        console.log(err);
        response.sendStatus(500);
    }
});

router.post('/add',async function(request,response){
    try{
        let findOrganisation = await org.getOrganisationByName(request.body.name);
        console.log(findOrganisation);
        if(findOrganisation.length != 0 ){throw new Error('Name already exists');}
        let newOrganisation = new Organisation(request.body);
        let result = await newOrganisation.addOrganisation();
        response.json({
            statut: 200,
            data: result
        });
    }catch(err){
        console.log(err);
        response.sendStatus(500);
    }
});

router.delete('/:orgId', async function(req, res){
         try{
            let result = await org.deleteOrganisation(req.params.orgId);
            res.json(result);
         }catch(err){
             console.log(err);
             response.sendStatus(500);
         }
 });

module.exports = router;