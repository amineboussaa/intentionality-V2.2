const express = require('express');
const router = express.Router();
const fs = require('fs'); 
const csv =require("csvtojson");
const Project = require('../Models/Project');
const Conccurent = require('../Models/Conccurent');
const Inspirant = require('../Models/Inspirant');

let project = new Project();

router.post('/add',async function(request,response){
  try{
        let findProject = await project.getProjectByName(request.body.name);
        if( findProject.length != 0){throw new Error('Name alerady exists');}
        let newProject = new Project(request.body);
        let result = await newProject.addProject();
        response.json({
          statut: 200,
          data: result
        });
  }catch(err){
    console.log(err);
    response.sendStatus(500);
  }
});

router.get('/list-by-organisation/:orgId', async function(request,response){
  try{
      let result = await project.getProjectsByOrganisation(request.params.orgId);
      response.json({
        statut: 200,
        data: result
      });
  }catch(err){
    console.log(err);
    response.sendStatus(500);
  }
});

router.get('/details/:projectId', async function(request,response){
  try{

      let result = await project.getProject(request.params.projectId);
      let conccurent = new Conccurent();
      let conccurentPages = await conccurent.getByProject(request.params.projectId);
      let inspirant = new Inspirant();
      let inspirantPages = await inspirant.getByProject(request.params.projectId);
      result.inspirantPages = inspirantPages;
      result.conccurentPages = conccurentPages;
      console.log(result);
      response.json({
        statut: 200,
        data: result
      });
  }catch(err){
    console.log(err);
    response.sendStatus(500);
  }
});


router.post('/addConcurrentPage', async function(request,response){
  try{
      let conccurent = new Conccurent(request.body);
      let result = await conccurent.addConccurent();
      response.json({
        statut: 200,
        data: result
      });
  }catch(err){
    console.log(err);
    response.sendStatus(500);
  }
});


router.post('/addUrl', async function(request,response){
  try{
      let result = await project.addUrl(request.body.idProject,request.body.principalUrl)
      response.json({
        statut: 200,
        data: result
      });
  }catch(err){
    console.log(err);
    response.sendStatus(500);
  }
});


router.post('/addInspirantPage', async function(request,response){
  try{
      let inspirant = new Inspirant(request.body);
      let result = await inspirant.addInspirant();
      console.log(result);
      response.json({
        statut: 200,
        data: result
      });
  }catch(err){
    console.log(err);
    response.sendStatus(500);
  }
});

router.get('/evaluation/:projectId', async function(request,response){
   try{
      let newProject = await project.getProject(request.params.projectId);
        if(newProject.length == 0){ 
        response.json({
          statut: 400,
          message: 'no sush project'
        });}
        let inputFilePath = '1/PostEvaluation/OutputFiles/Post_model_results_detailed.csv';

        csv({
          trim:true,
          delimiter: ';'
       })
        .fromFile(inputFilePath)
        .then((jsonObj)=>{
           let result = jsonObj[0];
           let tagsInputFilePath = '1/PostEvaluation/OutputFiles/Post_withAllTagsClean.csv';
           csv({
            trim:true,
            delimiter: ';'
           })
          .fromFile(tagsInputFilePath)
          .then((jsonObj)=>{
             result.tags = jsonObj[0].tags;
             response.json({
               statut: 200,
               data: result
             })
             
          })
           
        })
   }catch(err){
     console.log(err);
     response.sendStatus(500);
   }
});

router.get('/recommandation/:projectId', async function(request,response){
  try{
     let newProject = await project.getProject(request.params.projectId);
     if(newProject.length == 0){ 
       response.json({
         statut: 400,
         message: 'no sush project'
       });}
       let result = {};
       let inputFilePath = '1/PostRecommandation/OutputFiles/Post_recommandations.csv';
       csv({
        trim:true,
        delimiter: ';'
       })
      .fromFile(inputFilePath)
      .then((jsonObj)=>{
         result = jsonObj[0];
         response.json({
           statut: 200,
           data: result
         });
        });
  }catch(err){
    console.log(err);
    response.sendStatus(500);
  }
});

router.get('/reevaluate-data/:projectId', async function(request,response){
  try{
    
     let newProject = await project.getProject(request.params.projectId);
     if(newProject.length == 0){ 
       response.json({
         statut: 400,
         message: 'no sush project'
       });}
       let result = {
        'percentage': 55,
        'likes-from': 60,
        'likes-to': 80,
        'comments-from': 20,
        'share-from': 10,
        'share-to': 30
       };
       let inputFilePath = '1/PostEvaluation/OutputFiles/Post_withAllTagsClean.csv';
        csv({
        trim:true,
        delimiter: ';'
       })
      .fromFile(inputFilePath)
      .then((jsonObj)=>{
         result.tags = jsonObj[0].tags;
         response.json({
           statut: 200,
           data: result
         });
        });
  }catch(err){
    console.log(err);
    response.sendStatus(500);
  }
});

router.delete('/:projectId', async function(req, res){
  try{
    let result = await project.deleteProject(req.params.projectId);
    res.json(result);
  }catch(err){
    console.log(err);
    response.sendStatus(500);
  }
  
});


  module.exports = router;
