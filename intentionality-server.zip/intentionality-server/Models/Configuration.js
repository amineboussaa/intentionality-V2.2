const Promise = require('promise');
const connectionModel = require('../config/db');
const configModel = connectionModel.extend({
    tableName: "configapp",
});
class Configuration {
    constructor(config = {}){
        this.config = new configModel(config);
    }

    getConfiguration(){
        return new Promise((resolve, reject)=>{
            this.config.find('first',{}, function(err, rows) {
                if(err){reject(err);}
                resolve(rows);
            });
        });
    }
    updateConfiguration(){
        return new Promise((resolve,reject)=>{
          this.config.save(function(err,row){
              if(err){reject(err);}
              resolve(row);
          });
        });
    }

    set(field,value){
        this.config.set(field,value);
     }

}
module.exports = Configuration;
