const Promise = require('promise');
const connectionModel = require('../config/db');
const projectModel = connectionModel.extend({
    tableName: "project",
});
class Project {
    constructor(project = {}){
        this.project = new projectModel(project);
    }

    getAllprojects(){
        return new Promise((resolve, reject)=>{
            this.project.find('all',{}, function(err, rows) {
                if(err){reject(err);}
                resolve(rows);
            });
        });
    }

    getProjectsByOrganisation(orgId){
        return new Promise((resolve, reject)=>{
            this.project.find('all',{where: "idOrganisation="+orgId }, function(err, rows) {
                if(err){reject(err);}
                resolve(rows);
            });
        });
    }

    getProjectByName(nameProject){
        return new Promise((resolve, reject)=>{
            this.project.find('all',{where: `name='${nameProject}'`}, function(err, rows) {
                if(err){reject(err);}
                resolve(rows);
            });
        });
    }

    getProject(id){
        return new Promise((resolve, reject)=>{
            this.project.find('first',{where: "id="+id }, function(err, rows) {
                if(err){reject(err);}
                resolve(rows);
            });
        });
    }

    addUrl(id,url){
        return new Promise((resolve, reject)=>{
            this.project.query(`update project set principalUrl='${url}' where id='${id}'`, function(err, rows) {
                if(err){reject(err);}
                resolve(rows);
            });
        });
    }

    addProject(){
        return new Promise((resolve,reject)=> {
            this.project.save(function(err,row){
                if(err){reject(err);}
                resolve(row);
            });
        });
    }
    updateProject(){
        return new Promise((resolve,reject)=>{
          this.project.save(function(err,row){
              if(err){reject(err);}
              resolve(row);
          });
        });
    }

    deleteProject(id){
        return new Promise((resolve,reject)=>{
          this.project.set('id',id);
          this.project.remove(function(err,row){
            if(err){reject(err);}
            resolve(row);
          });
        });
    }

    set(field,value){
        this.config.set(field,value);
     }

}
module.exports = Project;
