const Promise = require('promise');
const connectionModel = require('../config/db');
const conccurentModel = connectionModel.extend({
    tableName: "competingpages",
});
class Conccurent {
    constructor(conccurent = {}){
        this.conccurent = new conccurentModel(conccurent);
    }

    addConccurent(){
        return new Promise((resolve,reject)=> {
            this.conccurent.save(function(err,row){
                if(err){reject(err);}
                resolve(row);
            });
        });
    }

    getByProject(idProject){
        return new Promise((resolve, reject)=>{
            this.conccurent.find('all',{where: `idProject='${idProject}'`}, function(err, rows) {
                if(err){reject(err);}
                resolve(rows);
            });
        });
    }
}

module.exports = Conccurent;