const Promise = require('promise');
const connectionModel = require('../config/db');
const inspirantModel = connectionModel.extend({
    tableName: "inspiringpages",
});
class Inspirant {
    constructor(inspirant = {}){
        this.inspirant = new inspirantModel(inspirant);
    }

    addInspirant(){
        return new Promise((resolve,reject)=> {
            this.inspirant.save(function(err,row){
                if(err){reject(err);}
                resolve(row);
            });
        });
    }
    getByProject(idProject){
        return new Promise((resolve, reject)=>{
            this.inspirant.find('all',{where: `idProject='${idProject}'`}, function(err, rows) {
                if(err){reject(err);}
                resolve(rows);
            });
        });
    }
}

module.exports = Inspirant;