const Promise = require('promise');
const connectionModel = require('../config/db');
const orgModel = connectionModel.extend({
    tableName: "organisation",
});
class Organisation {
    constructor(org = {}){
        this.org = new orgModel(org);
    }

    getAllOrganisations(){
        return new Promise((resolve, reject)=>{
            this.org.find('all',{}, function(err, rows) {
                if(err){reject(err);}
                resolve(rows);
            });
        });
    }

    getOrganisation(id){
        return new Promise((resolve, reject)=>{
            this.org.find('first',{where: "id="+id}, function(err, rows) {
                if(err){reject(err);}
                resolve(rows);
            });
        });
    }

    getOrganisationByName(orgName){
        return new Promise((resolve, reject)=>{
            this.org.find('first',{where: `name='${orgName}'`}, function(err, rows) {
                if(err){reject(err);}
                resolve(rows);
            });
        });
    }

    addOrganisation(){
        return new Promise((resolve, reject)=>{
            this.org.save(function(err, rows) {
                if(err){reject(err);}
                resolve(rows);
            });
        });
    }

    updateOrganisation(){
        return new Promise((resolve,reject)=>{
          this.org.save(function(err,row){
              if(err){reject(err);}
              resolve(row);
          });
        });
    }

    deleteOrganisation(id){
        return new Promise((resolve,reject)=>{
          this.org.set('id',id);
          this.org.remove(function(err,row){
            if(err){reject(err);}
            resolve(row);
          });
        });
    }

    set(field,value){
        this.config.set(field,value);
     }

}
module.exports = Organisation;
