const Promise = require('promise');
const connectionModel = require('../config/db');
const userModel = connectionModel.extend({
    tableName: "user",
});


class User {
    constructor(user={}){
        this.user = new userModel(user);
    }


    getAllUsers(){
        return new Promise((resolve, reject)=>{
            this.user.find('all',{}, function(err, rows, fields) {
                if(err){reject(err);}
                resolve(rows);
            });
        });
    }

     getByEmail(email){
         return new Promise((resolve,reject)=>{
            this.user.find('first', {where: "email='"+email+"'"}, function(err, row) {
                if(err){reject(err);}
                resolve(row);
            });
         });
    };


     getById(id){
         return new Promise((resolve,reject)=>{
            this.user.find('first', {where: "id="+id}, function(err, row) {
                if(err){reject(err);}
                resolve(row);
            });
         });
    };


      addUser(){
        return new Promise((resolve,reject)=>{
          this.user.save(function(err,row){
              if(err){reject(err);}
              resolve(row);
          });
        });
    }


   comparePassword(candidatePassword,password){
            return (candidatePassword === password)? true :false;
    }

    set(field,value){
       this.user.set(field,value);
    }

}

module.exports = User;
